#include <iostream>
#include <iomanip> // 
using namespace std;

int main() {
    int Fuel, Rent, Bills, Total;
    cout << "Enter the amount spent on Fuel: ";
    cin >> Fuel;
    cout << "Enter the amount spent on Rent: ";
    cin >> Rent;
    cout << "Enter the amount spent on Bills: ";
    cin >> Bills;
    Total = Fuel + Rent + Bills;
    cout << "\nExpenditure Summary\n";
    cout << "--------------------------------\n";
    cout << left << setw(15) << "Fuel:" << Fuel << endl;
    cout << left << setw(15) << "Rent:" << Rent << endl;
    cout << left << setw(15) << "Bills:" << Bills << endl;
    cout << left << setw(15) << "Total:" << Total << endl;
    cout << "--------------------------------\n";

    return 0;
}