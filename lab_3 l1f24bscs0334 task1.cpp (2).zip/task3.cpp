#include<iostream>
using namespace std;
int main()
{
	int x = 5;
	cout << "the value of x is" << x << endl;
	return 0;
}