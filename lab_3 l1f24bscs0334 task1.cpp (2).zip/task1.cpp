# include<iostream>
using namespace std;
int main()
{
	int number = 0;
	cout << "please enter an integer";
	cin >> number;
	cout << "you entered:" << number;
	return 0;
}