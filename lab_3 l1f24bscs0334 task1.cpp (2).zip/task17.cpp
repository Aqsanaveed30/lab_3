#include <iostream>
using namespace std;

int main() {
    int speed = 20; 
    int time = 10;   
    int distance;     
    distance = speed * time;
    cout << "The distance is: " << distance << endl;
    return 0;
}