#include <iostream>
using namespace std;

int main() {
    const int totalCookies = 40;        // Total number of cookies in the bag
    const int servings = 10;             // Total servings in the bag
    const int caloriesPerServing = 300;  // Calories per serving

    // Calculate total calories in the bag
    int totalCalories = servings * caloriesPerServing;

    int cookiesEaten;
    // Ask the user for the number of cookies eaten
    cout << "Enter the number of cookies you ate: ";
    cin >> cookiesEaten;

    // Check if the input is valid
    if (cookiesEaten < 0) {
        cout << "You cannot eat a negative number of cookies." << endl;
        return 1; // Exit with an error code
    }
    if (cookiesEaten > totalCookies) {
        cout << "You cannot eat more cookies than available in the bag." << endl;
        return 1; // Exit with an error code
    }

    // Calculate calories consumed
    int caloriesConsumed = (cookiesEaten * totalCalories) / totalCookies;

    // Display the result
    cout << "You consumed " << caloriesConsumed << " calories." << endl;

    return 0;
}