#include <iostream>
#include <iomanip> 
using namespace std;
const double PI = 3.14159265358979323846; 
int main() {
    double radius, height, volume, surfaceArea;
    cout << "Enter the radius of the cylinder (in units): ";
    cin >> radius;
    cout << "Enter the height of the cylinder (in units): ";
    cin >> height;
    // Calculate volume
    volume = PI * radius * radius * height;
    surfaceArea = 2 * PI * radius * (radius + height);
    cout << fixed << setprecision(2); // Set output to two decimal places
    cout << "Volume of the cylinder: " << volume << " cubic units" << endl;
    cout << "Surface area of the cylinder: " << surfaceArea << " square units" << endl;
    return 0;
}