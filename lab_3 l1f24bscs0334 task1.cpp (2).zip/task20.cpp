#include <iostream>
using namespace std;

int main() {
    // Meal prices
    const int gourmetPrice = 50;  // Price for Gourmet meal
    const int standardPrice = 30;  // Price for Standard meal
    const int fastPrice = 20;      // Price for Fast meal

    // Variables to hold the number of meals sold
    int gourmetSold, standardSold, fastSold;

    // Prompt user for the number of meals sold
    cout << "Enter the number of Gourmet meals sold: ";
    cin >> gourmetSold;

    cout << "Enter the number of Standard meals sold: ";
    cin >> standardSold;

    cout << "Enter the number of Fast meals sold: ";
    cin >> fastSold;

    // Calculate total revenue
    int totalRevenue = (gourmetSold * gourmetPrice) + 
                       (standardSold * standardPrice) + 
                       (fastSold * fastPrice);

    // Display the total revenue
    cout << "\nTotal revenue generated from meal sales: Rs " << totalRevenue << endl;

    return 0;
}