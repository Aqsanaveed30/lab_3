#include <iostream>
using namespace std;

int main() {
    float radius, area;
    const float pi = 3.14; cout << "Enter the radius: ";
    cin >> radius;
 area = pi * (radius * radius);cout << "The area of the circle is: " << area << endl;

    return 0;
}