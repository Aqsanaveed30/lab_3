#include<iostream>
using namespace std;
int main()
{
	int number;
	cout << "Enter an integer:";
	cin >> number;
	int square = number * number;
	cout << "The square of " << " is " << square << endl;
	return 0;
}