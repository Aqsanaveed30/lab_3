#include<iostream>
using namespace std;
int main()
{
	cout << "\t\thello, class!\n\tWelcome to the ITC-Lab week-03"<<endl;
	return 0;
}