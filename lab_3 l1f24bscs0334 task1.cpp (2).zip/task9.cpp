#include<iostream>
using namespace std;

int main()
{
	int x,y,area,pr;
	cout << "Enter the width:- \n";
	cin >> x;
	cout << "Enter the length:- \n";
	cin >> y;
	area = x * y;
	pr = 2 * (x + y);
	cout << "The Area is:-" << area << endl;
	cout << "The Perimeter is:-" << pr << endl;
	return 0;
}