#include <iostream>
#include <iomanip> // 
using namespace std;

int main() {
    string studentName;
    string subject1, subject2, subject3;
    float score1, score2, score3;
    cout << "Enter the student's name: ";
    getline(cin, studentName); // 
    cout << "Enter the name of subject 1: ";
    getline(cin, subject1);
    cout << "Enter the score for " << subject1 << ": ";
    cin >> score1;
 #include <iostream>
#include <iomanip> // 
using namespace std;

int main(){
    float priceWheat, priceRice, priceSugar;
    int quantityWheat, quantityRice, quantitySugar;
    cout << "Enter the price of Wheat: ";
    cin >> priceWheat;
    cout << "Enter the quantity of Wheat: ";
    cin >> quantityWheat;
     cout << "Enter the price of Rice: ";
    cin >> priceRice;
    cout << "Enter the quantity of Rice: ";
    cin >> quantityRice;
    cout << "Enter the price of Sugar: ";
    cin >> priceSugar;
    cout << "Enter the quantity of Sugar: ";
    cin >> quantitySugar;  float totalWheat = priceWheat * quantityWheat;
    float totalRice = priceRice * quantityRice
