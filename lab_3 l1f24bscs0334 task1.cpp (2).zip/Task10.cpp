  #include <iostream>
using namespace std;

int main() {
    int totalMinutes, hours, minutes;
    cout << "Enter the total number of minutes: ";
    cin >> totalMinutes;
    hours = totalMinutes / 60;
    minutes = totalMinutes % 60;
     cout << totalMinutes << " minutes is equal to " << hours << " hours and " << minutes << " minutes." << endl;

    return 0;
}