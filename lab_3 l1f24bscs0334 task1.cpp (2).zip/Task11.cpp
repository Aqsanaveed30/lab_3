 #include <iostream>
using namespace std;

int main() {
    int hours, minutes, totalMinutes;

    // Input hours and minutes from the user
    cout << "Enter the number of hours: ";
    cin >> hours;

    cout << "Enter the number of minutes: ";
    cin >> minutes;

    // Calculate total minutes
    totalMinutes = (hours * 60) + minutes;

    // Display the result
    cout << "Total minutes: " << totalMinutes << " minutes." << endl;

    return 0;
}