#include <iostream>
#include <iomanip> // 
using namespace std;

int main() {
    string studentName;
    string subject1, subject2, subject3;
    float score1, score2, score3;
    cout << "Enter the student's name: ";
    getline(cin, studentName); // 
    cout << "Enter the name of subject 1: ";
    getline(cin, subject1);
    cout << "Enter the score for " << subject1 << ": ";
    cin >> score1;
    cin.ignore(); // 

    cout << "Enter the name of subject 2: ";
    getline(cin, subject2);
    cout << "Enter the score for " << subject2 << ": ";
    cin >> score2;
    cin.ignore(); 
     cout << "Enter the name of subject 3: ";
    getline(cin, subject3);
    cout << "Enter the score for " << subject3 << ": ";
    cin >> score3;
     float totalScore = score1 + score2 + score3;
    float averageScore = totalScore / 3;
 cout << "\nResult Sheet\n";
    cout << "----------------------------------\n";
    cout << left << setw(20) << "Student Name:" << studentName << endl;
    cout << left << setw(20) << subject1 + ":" << score1 << endl;
    cout << left << setw(20) << subject2 + ":" << score2 << endl;
    cout << left << setw(20) << subject3 + ":" << score3 << endl;
    cout << "----------------------------------\n";
    cout << left << setw(20) << "Total Score:" << totalScore << endl;
    cout << left << setw(20) << "Average Score:" << averageScore << endl;

    return 0;
}