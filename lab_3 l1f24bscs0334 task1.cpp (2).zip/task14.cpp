#include<iostream>
using namespace std;

int main()
{
	int classa, classb, classc, price[3],total;            //quantity[0] = val of wheat, quantity[1] = val of rice,quantity[2] = val of sugar 
	cout << "Seats sold for classA:-\n";
	cin >> classa;
	cout << "Seats sold for classB:- \n";
	cin >> classb;
	cout << "Seats sold for classC:- \n";
	cin >> classc;
	price[0] = classa * 15;
	price[1] = classb * 12;
	price[2] = classc * 9;
	total = price[0]+price[1]+price[2];
	cout << "Total income generated from class A tickets:- \n" << price[0] << endl;
	cout << "Total income generated from class B tickets:- \n" << price[1] << endl;
	cout << "Total income generated from class C tickets:- \n" << price[2] << endl;
	cout << "Total income generated from tickets:- \n" << total << endl;
	return 0;
}