#
#include <iostream>
#include <iomanip> 
using namespace std;

int main() {
    // Course prices
    const int basicPrice = 500;      
    const int advancedPrice = 1000;  
    const int professionalPrice = 2000; 
    int basicCourses, advancedCourses, professionalCourses;
    cout << "Enter the number of Basic courses: ";
    cin >> basicCourses;
    cout << "Enter the number of Advanced courses: ";
    cin >> advancedCourses;
    cout << "Enter the number of Professional courses: ";
    cin >> professionalCourses;
    int totalCost = (basicCourses * basicPrice) + 
                    (advancedCourses * advancedPrice) + 
                    (professionalCourses * professionalPrice)
    double discount = 0.15;
    double discountAmount = totalCost * discount;
    double finalAmount = totalCost - discountAmount;
    cout << fixed << setprecision(2); 
    cout << "\nTotal cost before discount: Rs " << totalCost << endl;
    cout << "Discount applied: Rs " << discountAmount << endl;
    cout << "Final amount due: Rs " << finalAmount << endl;
    return 0;
}